# Report 02 — Shell and Kemper - 530 Report

**Cognos source:** Public Folders > Michelman Reporting > Production and Shipping > Contract Manufacturing Orders > *Dashboard - CM Overview LIVE* (embedded panel).
**Report name (Cognos):** `Shell and Kemper - 530 Report`
**Page rendered in the dashboard panel:** `Main Report - 530` (list `List2`, query `Main w Routing 530`).

> **OBJECTIVE:** Show every open Contract-Manufacturing sales-order line sitting at **Next Status 530** (company `00010`), with its owner/planner, so planners can work their queue. A red **"Number of Errors"** counter flags lines whose planner does not map to a known owner.
> **SCOPE:** Company `00010`, Next Status **= 530**, item present (2nd item not null). One row per order line × bulk item × planner × work center.

This is **page 1 of the shared "CM Overview LIVE" PBIP** (see `_PROGRESS.md`). Build it as the first page of that PBIP.

---

## 0. On-page plaintext (verbatim, for fidelity)

- **Page header title** (blue, bold, large): `Shell and Kemper - 530 Report`
- **Prompt label** (bold): `Select the Planner `  → dropdown (see slicer below)
- **Counter label** (bold, black): `    Number of Errors = ` immediately followed by the count value `N` (the value cell turns **red with white text** when `N > 0`).
- **Empty-state text:** `No Data Available`

---

## 1. Queries (Power Query)

| Query | File | Feeds |
|---|---|---|
| `Shell_Kemper_530` | `Shell_Kemper_530.m` | The visible **530 detail list** (main deliverable) |
| `Number_of_Errors` | `Number_of_Errors.m` | The **"Number of Errors = N"** scalar *(optional — a DAX measure is recommended instead, see §4)* |

Both connect to `Sql.Database("ODSPROD","ODS")` and run native T-SQL against `PRODDTA` (folding on), following the repo's canonical JDE/ODS query `edw_model/JDE_Orders/Orders.m` and report 01: same `Value.NativeQuery(Source, "<T-SQL>", null, [EnableFolding=true])` shape, inline Julian `DATEADD/DATEFROMPARTS` decode, `LTRIM(RTRIM(...))` trims, `SDLNID/1000.0` line scaling, and a trailing `Table.TransformColumnTypes`. Paste each into **Power BI Desktop → Get Data → Blank Query → Advanced Editor**. Set the server name to match your SSMS connection if it differs from `ODSPROD`. (ODS mirrors JDE, so table reachability is a given — no pre-flight check needed. Note the schema convention: business tables live in `PRODDTA`; the UDC master `F0005` lives in `PRODCTL` — not used by this query.)

### The 4 Cognos generated-SQL blocks → what we built

| Cognos block | What it is | Built as |
|---|---|---|
| Block 1 | error **COUNT**, `Next_Status='530'` | `Number_of_Errors.m` (or DAX measure) |
| **Block 2** | **DETAIL list**, `Next_Status='530'` | **`Shell_Kemper_530.m`** ← the panel |
| Block 3 | error COUNT, no `='530'` filter (all 525–550) | *not built* — feeds Cognos page `Main Report - All`, which is **not** in the dashboard panel |
| Block 4 | DETAIL list, no `='530'` filter | *not built* — same "All" page |

Cognos also has a 3rd page `Planner Responsibilities` (a **static** "Planner Segregation of Duties" reference matrix — no query). Out of scope for this panel; rebuild later as a static table if wanted.

---

## 2. Cognos → PBI column mapping (visible list, left → right)

Header labels are the Cognos `label=` attributes from the list; query columns are the `Shell_Kemper_530.m` output names (already the Cognos labels).

| # | Cognos label | Query column | JDE source |
|---|---|---|---|
| 1 | Promised Ship | `Promised Ship` | `F4211.SDPDDJ` (Julian → date) |
| 2 | Requested | `Requested` | `F4211.SDDRQJ` (Julian → date) |
| 3 | Plant | `Plant` | `F4211.SDMCU` (trimmed) |
| 4 | Ship To | `Ship To` | `F0101.ABALPH` via `SDSHAN` |
| 5 | CS | `CS` | `F0101.ABAC06` (Customer Segmentation) via `SDSHAN` |
| 6 | Order# | `Order#` | `F4211.SDDOCO` |
| 7 | Line# | `Line#` | `F4211.SDLNID / 1000` |
| 8 | Bulk | `Bulk` | `F554101.IMBULK` via item master `IMITM` |
| 9 | Item | `Item` | `F4211.SDLITM` (2nd item, trimmed) |
| 10 | Description | `Description` | decode: `NEWITEMFG`/`NEWITEMPKG` → `SDDSC1`, else `' '` |
| 11 | Owner | `Owner` | planner-number → name decode (`F4102.IBANPL`), else `ERROR` |
| 12 | Planner | `Planner` | raw `F4102.IBANPL` |
| 13 | Status | `Status` | `F4211.SDNXTR` (= `530`) |
| 14 | Qty | `Primary Qty` | `AVG` of `F4211.SDPQOR/10000` (see quirk §6) |
| 15 | UOM | `Primary UOM` | `F4211.SDUOM1` |
| 16 | Qty | `Secondary Qty` | `AVG` of `F4211.SDSQOR/10000` (see quirk §6) |
| 17 | UOM | `Secondary UOM` | `F4211.SDUOM2` |
| 18 | Order Date | `Order Date` | `F4211.SDTRDJ` (Julian → date) |
| 19 | CSR Name | `CSR Name` | `F0101.ABALPH` via `F42140` (`CMRTYPE='CSR'`, `CMSLSM→ABAN8`) |
| 20 | Work Ctr | `Work Ctr` | `Routing13.Work_Center` (`F3312.CWMCU`) |
| 21 | MPF | `MPF` | `F4211.SDPRP4` |

> Two columns are both labelled **Qty** and two both **UOM** in Cognos (primary then secondary). In the PBI table, keep the field order above; optionally rename the visible headers to `Primary Qty / Primary UOM / Secondary Qty / Secondary UOM` for clarity, or leave as `Qty / UOM / Qty / UOM` to match Cognos exactly.

The planner → owner decode (identical in the detail and the count):

| Planner # | Owner | | Planner # | Owner |
|---|---|---|---|---|
| 324363 | Eric | | 316775 | Lance |
| 20444 | Eric | | 334927 | Tammy |
| 20445 | Lance | | 290808 | David Kramer |
| 291740 | Mark Tilley | | 335951 | Lance |
| 328907 | Lance | | 300021 | Tammy |
| 333530 | Lance | | 324287 | Brent |
| *(any other)* | **ERROR** | | | |

---

## 3. Visuals

### Page header (Text box)
- Title **"Shell and Kemper - 530 Report"** — **blue**, bold (Cognos page-header style is `color:blue`). *(Note: unlike report 01's red title, this panel's title is blue.)*

### Visual A — the 530 detail (Table)
- Visual type: **Table**.
- Fields in the order of the §2 table (Promised Ship … MPF).
- **Number format:** `Primary Qty` and `Secondary Qty` → whole number, **0 decimals**, right-aligned (Cognos `numberFormat decimalSize="0"`).
- **Date format:** `Promised Ship`, `Requested`, `Order Date` → medium date (Cognos `dateStyle="medium"`, e.g. `Jul 1, 2026`).
- `Order#`, `Planner` → whole number, **no thousands separator** (IDs).
- Header styling to match Cognos: column titles **bold, red text, 1pt solid black border**; body cells **1pt solid black border** (thin grid). Red header hex `#FF0000`.
- **Sort:** `Bulk` ▲, then `Promised Ship` ▲, then `Order#` ▲, then `Line#` ▲, then `Owner` ▲ (all ascending). *The `.m` intentionally omits `ORDER BY` — an ORDER BY inside the folded subquery is illegal in SQL Server — so set this sort in the visual.* Cognos sorts NULLs last; PBI table sorting puts blanks last on ascending, which matches.

### Visual B — "Number of Errors" counter
Two options — **the DAX measure (§4) is recommended.**
- Render as a **Card** (or a text box + card) reading `Number of Errors = N`.
- Apply conditional formatting so the value goes **red background / white text when N > 0** (Cognos `FLAG ERROR in HEADER 530`). See §5.

### Slicer — "Select the Planner"
- Cognos prompt `?Owner1?` is an **optional single-select** dropdown filtering `[NEW OWNER]=?Owner1?`.
- Build a **Slicer** on `Shell_Kemper_530[Owner]`, style **Dropdown**, **single-select**.
- Options present in Cognos: `Brent, Eric, Lance, Tammy, Mark Tilley, David Kramer, ERROR` (these are exactly the distinct `Owner` values, so the slicer populates itself).
- Default = **no selection** (shows all owners). The Cognos label placeholder shown when nothing is picked is the parameter name `Owner1`; there is no pre-selected planner.

---

## 4. "Number of Errors" — recommended DAX measure

Rather than load `Number_of_Errors.m`, add a measure on the detail table so the counter ties 1:1 to the red rows:

```DAX
Number of Errors =
CALCULATE (
    COUNTROWS ( 'Shell_Kemper_530' ),
    'Shell_Kemper_530'[Owner] = "ERROR"
)
```

- This counts the visible 530 rows owned by `ERROR`. With the `DISTINCT`-Routing13 rewrite, it equals the value `Number_of_Errors.m` returns and equals Cognos's `total([FLAG ERROR])`.
- It also respects the "Select the Planner" slicer (if a planner is chosen, the counter reflects that filter) — matching Cognos, where the counter query and the list share the `Owner1` prompt.
- If you prefer a fully static scalar independent of the page (or a standalone card that ignores slicers), load `Number_of_Errors.m` instead and show its single `Number of Errors` value.

---

## 5. Visual fidelity — conditional formatting (exact rules from the Report XML)

Three named conditional styles are defined in the Cognos XML (`<namedConditionalStyles>`). Reproduce all three.

### (a) Red row highlight — `Flag ERROR`
- **Rule:** `[NEW OWNER] = 'ERROR'` (i.e. `Shell_Kemper_530[Owner] = "ERROR"`).
- **Style:** `background-color:red; color:white` → **red fill `#FF0000`, white text `#FFFFFF`**.
- **Applied to:** **every** body cell of the row (all 21 columns carry this conditional style), so the whole row turns red.
- **PBI:** add a background-color rule (and a font-color rule) on every column, driven by a measure:
  ```DAX
  Is Error Row = IF ( SELECTEDVALUE ( 'Shell_Kemper_530'[Owner] ) = "ERROR", 1, 0 )
  ```
  Table → each column → Cell elements → **Background color** = `#FF0000` when `Is Error Row = 1`; **Font color** = `#FFFFFF` when `Is Error Row = 1`. (Format-by field-value works too since `Owner` is on the row.)

### (b) Yellow cell highlight on the **Requested** column — `Flag 530 - Request Date Sooner`
- **Rule (confirmed exact):** `[Requested Date] < [Promised Ship Date]`.
- **Style:** `background-color:yellow` → **yellow fill `#FFFF00`** (text unchanged).
- **Applied to:** the **Requested** column body cell **only** (not the whole row). *Note the Requested column also carries the `Flag ERROR` red rule; red (error) takes precedence over yellow because both set the background — in Cognos the ERROR style is listed after the yellow style. In PBI, gate the yellow so it does not fire on error rows (see below).*
- **PBI:** background-color rule on the `Requested` column only:
  ```DAX
  Requested Flag =
  VAR req = SELECTEDVALUE ( 'Shell_Kemper_530'[Requested] )
  VAR prom = SELECTEDVALUE ( 'Shell_Kemper_530'[Promised Ship] )
  RETURN
      IF ( 'Shell_Kemper_530'[Owner]... )  -- see note
  ```
  Simplest: color `Requested` **yellow `#FFFF00`** when `Requested < Promised Ship` **AND** `Owner <> "ERROR"` (so red wins on error rows), e.g.:
  ```DAX
  Requested Cell Color =
  IF (
      SELECTEDVALUE ( 'Shell_Kemper_530'[Owner] ) = "ERROR", "#FF0000",
      IF (
          SELECTEDVALUE ( 'Shell_Kemper_530'[Requested] )
              < SELECTEDVALUE ( 'Shell_Kemper_530'[Promised Ship] ),
          "#FFFF00", BLANK ()
      )
  )
  ```
  Use this as the **Background color → format by field value** for the `Requested` column.

### (c) Red "Number of Errors" counter — `FLAG ERROR in HEADER 530`
- **Rule:** `[COUNT ERROR] > 0` (i.e. `[Number of Errors] > 0`).
- **Style:** `background-color:red; color:white`.
- **PBI:** conditional format the Card's value: background `#FF0000`, font `#FFFFFF` when `[Number of Errors] > 0`.

**Color reference:** red `#FF0000`, white `#FFFFFF`, yellow `#FFFF00`. Grid border `1pt solid black`. Title/labels blue `#0000FF`. *(These are the literal CSS values in this report — note they differ from report 01's `#e40011` / `#001eff`.)*

---

## 6. Known Cognos quirks (PARITY MODE — reproduced on purpose)

### Quirk 1 — quantities use `AVG`, not `SUM`
The final Cognos step computes `average([Primary Quantity Ordered])` and `average([Secondary Quantity Ordered])` (see the `Main w Routing 530` selection). `Shell_Kemper_530.m` reproduces this with `AVG(...)`.

- **Effect here:** the final `GROUP BY` is at the order-line grain (each group is a single line × bulk × planner × work center), and the `MAIN8`/`Main_w_Bulk12` steps already `SUM`med the quantities to that grain. So the values being averaged within a group are identical repeats, and `AVG` returns that same value — it ties to the live report. The quirk only bites if a future change makes a final group span multiple distinct line quantities.
- **Corrected form (when planners confirm):** replace the two `AVG(...)` with `SUM(...)` in `Shell_Kemper_530.m`. Everything else (joins, filters, grouping) stays the same.

### Quirk 2 — `FULL OUTER JOIN` to Routing that behaves like a left join
Cognos `FULL OUTER JOIN`s `Main w Bulk` to `Routing` on `Bulk Item = 2nd Item Number`, then filters `WHERE [2nd Item Number] <> null`, which discards the routing-only side. We keep the `FULL OUTER JOIN` (valid in SQL Server) for faithfulness; the net effect is that order lines with no matching work center still appear (`Work Ctr` blank), and work centers with no order line are dropped.

### Note — Routing13 reduced to `DISTINCT`
Cognos's `Routing13` is a heavily grouped subquery, but the only column consumed downstream is `Work_Center`, and the final `GROUP BY` collapses on `Work_Center` (not on the routing dates Cognos grouped by). `Shell_Kemper_530.m` therefore builds Routing13 as `SELECT DISTINCT (Item_Branch, 2nd item, Work_Center)` — result-equivalent after the collapse and fold-friendly. If you later need the routing dates/quantities, expand it back to the full grouped form.

---

## 7. Refresh / "as of" behavior
`Routing13`'s period-end-date window uses `CAST(GETDATE() AS date)` for Oracle `sysdate` (`> today + 31 days`), so the report is **"as of the last refresh."** Schedule a daily refresh. The only prompt is the optional **Owner** slicer; there are no date parameters.

---

## 8. Validation checklist
- [ ] Refresh `Shell_Kemper_530` — no errors; rows come back at `Status = 530` only.
- [ ] Open the live Cognos `Shell and Kemper - 530 Report` (530 panel) the same day and compare **row count** and **`Number of Errors = N`** to the PBI page (parity mode should match).
- [ ] Spot-check that **ERROR** rows render **whole-row red / white text**, and that a row with `Requested < Promised Ship` shows the **Requested** cell **yellow** (except on error rows, where red wins).
- [ ] Confirm the **Owner** slicer filters the list (and, if using the DAX measure, the counter) to the chosen planner.
- [ ] Confirm sort = Bulk ▲, Promised Ship ▲, Order# ▲, Line# ▲, Owner ▲.
- [ ] Confirm `Primary/Secondary Qty` show 0 decimals and `Order#`/`Planner` show no thousands separator.

---

## 9. Open items / assumptions
- **Blocks 3 & 4 (the un-filtered "All" variant) are not built** — they feed the Cognos `Main Report - All` page, which is a separate page not shown in the dashboard's 530 panel. Build later if the dashboard is found to embed it.
- **`Planner Responsibilities`** (page 3) is a static "Planner Segregation of Duties" reference grid (no query). Not built; recreate as a static table/image if the panel needs it.
- **`Line#` uses `SDLNID / 1000.0`** (float division, matching Oracle) so sub-lines like `1.5` survive. If planners want whole line numbers only, switch to integer `/1000`.
- **Planner decode compares numeric `IBANPL` to string literals** (`'324363'` etc.); SQL Server implicitly converts to numeric (matching Oracle `decode`). No leading-zero planners appear in the list, so this is safe.
- **Owner slicer default:** Cognos leaves it unselected (`use="optional"`); assumed the same here (show all). Confirm with the planners whether a specific planner should be the landing default.
